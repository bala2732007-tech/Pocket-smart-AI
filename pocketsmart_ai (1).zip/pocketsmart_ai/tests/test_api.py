import os
os.environ["DATABASE_URL"] = "sqlite:///./test_pocketsmart.db"
os.environ["SECRET_KEY"] = "test-secret"
from fastapi.testclient import TestClient
from app.main import app


def test_health():
    with TestClient(app) as client:
        assert client.get('/health').json()['status'] == 'ok'


def test_register_login_and_home():
    with TestClient(app) as client:
        email='test@example.com'; password='password123'
        r=client.post('/register',json={'email':email,'password':password})
        assert r.status_code in (200,409)
        if r.status_code==409: r=client.post('/login',json={'email':email,'password':password})
        token=r.json()['access_token']
        h={'Authorization':f'Bearer {token}'}
        r=client.post('/generate-home',headers=h,json={'budget':50000,'rooms':['Living Room'],'items':[{'name':'light','quantity':2}],'style':'modern','city':'Chennai'})
        assert r.status_code==200
        assert 'recommendations' in r.json()
