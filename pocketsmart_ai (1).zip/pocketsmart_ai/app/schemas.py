from typing import Literal
from pydantic import BaseModel, Field, EmailStr, field_validator

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)

class LoginRequest(RegisterRequest): pass

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class RoomItem(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    quantity: int = Field(ge=1, le=50)
    priority: Literal["essential", "nice-to-have"] = "nice-to-have"

class HomeRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    rooms: list[str] = Field(min_length=1, max_length=10)
    items: list[RoomItem] = Field(min_length=1, max_length=30)
    style: str = Field(default="modern", max_length=80)
    city: str = Field(default="Chennai", max_length=100)

class PartyRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    guests: int = Field(ge=1, le=5000)
    event_type: str = Field(min_length=2, max_length=80)
    venue: str = Field(default="home", max_length=100)
    city: str = Field(default="Chennai", max_length=100)
    preferences: str = Field(default="", max_length=500)

class JewelryRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    occasion: str = Field(min_length=2, max_length=80)
    style: str = Field(default="elegant", max_length=80)
    outfit_description: str = Field(default="", max_length=500)

class RecommendationItem(BaseModel):
    name: str
    category: str
    price: float
    platform: str
    url: str
    reason: str

class PlannerResponse(BaseModel):
    planner: str
    budget: float
    allocation: dict[str, float]
    summary: str
    recommendations: list[RecommendationItem]
    ai_used: bool
    note: str | None = None
