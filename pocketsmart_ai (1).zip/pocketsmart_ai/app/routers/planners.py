import json, os, uuid
from pathlib import Path
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session
from ..auth import get_current_user
from ..database import Recommendation, User, get_db
from ..schemas import HomeRequest, PartyRequest, JewelryRequest
from ..services.recommender import home, party, jewelry
from ..config import get_settings

router = APIRouter(tags=["planners"])


def save_history(db, user, planner, request_obj, result):
    db.add(Recommendation(user_id=user.id, planner=planner, request_json=json.dumps(request_obj, default=str), result_json=json.dumps(result, default=str)))
    db.commit()

@router.post("/generate-home")
def generate_home(data: HomeRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    result = home(data); save_history(db,user,"home",data.model_dump(),result); return result

@router.post("/generate-party")
def generate_party(data: PartyRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    result = party(data); save_history(db,user,"party",data.model_dump(),result); return result

@router.post("/generate-jewelry")
async def generate_jewelry(budget: float = Form(...), occasion: str = Form(...), style: str = Form("elegant"), outfit_description: str = Form(""), outfit_image: UploadFile | None = File(None), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if budget <= 0: raise HTTPException(422, "Budget must be greater than zero")
    image_bytes = None; mime = None
    if outfit_image:
        allowed = {"image/jpeg", "image/png", "image/webp"}
        if outfit_image.content_type not in allowed: raise HTTPException(400, "Only JPG, PNG and WebP images are supported")
        data = await outfit_image.read()
        if len(data) > get_settings().max_upload_mb * 1024 * 1024: raise HTTPException(413, "Image is too large")
        image_bytes, mime = data, outfit_image.content_type
    payload = JewelryRequest(budget=budget, occasion=occasion, style=style, outfit_description=outfit_description)
    result = jewelry(payload, image_bytes, mime); save_history(db,user,"jewelry",payload.model_dump(),result); return result
