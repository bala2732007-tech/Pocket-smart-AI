import json
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..auth import get_current_user
from ..database import User, Recommendation, get_db

router = APIRouter(tags=["session"])

@router.get("/session-info")
def session_info(user: User = Depends(get_current_user)):
    return {"logged_in": True, "user_id": user.id, "email": user.email}

@router.get("/session-data")
def session_data(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    count = db.query(Recommendation).filter(Recommendation.user_id == user.id).count()
    return {"user_id": user.id, "recommendation_count": count}

@router.get("/history")
def history(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(Recommendation).filter(Recommendation.user_id == user.id).order_by(Recommendation.created_at.desc()).limit(50).all()
    return [{"id": r.id, "planner": r.planner, "created_at": r.created_at.isoformat(), "request": json.loads(r.request_json), "result": json.loads(r.result_json)} for r in rows]

@router.get("/recommendations-details/{recommendation_id}")
def recommendation_details(recommendation_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = db.query(Recommendation).filter(Recommendation.id == recommendation_id, Recommendation.user_id == user.id).first()
    if not r: return {"detail": "Recommendation not found"}
    return {"id": r.id, "planner": r.planner, "request": json.loads(r.request_json), "result": json.loads(r.result_json)}
