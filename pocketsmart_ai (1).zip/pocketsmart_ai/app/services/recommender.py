import json, re
from typing import Any
from .catalog import catalog_for, search_url
from ..config import get_settings

settings = get_settings()


def _extract_json(text: str) -> dict[str, Any] | None:
    text = text.strip()
    try: return json.loads(text)
    except json.JSONDecodeError: pass
    match = re.search(r"\{.*\}", text, re.S)
    if not match: return None
    try: return json.loads(match.group(0))
    except json.JSONDecodeError: return None


def _base_items(planner: str, budget: float, preferred_categories: set[str] | None = None):
    rows = catalog_for(planner)
    if preferred_categories:
        rows = sorted(rows, key=lambda x: (x[1] not in preferred_categories, x[2]))
    out = []
    spent = 0.0
    target = budget * 0.92
    for name, category, price, platform, query in rows:
        if spent + price <= target:
            out.append({"name": name, "category": category, "price": float(price), "platform": platform, "url": search_url(platform, query), "reason": "Fits the demo catalog budget and planner category."})
            spent += price
        if len(out) >= 8: break
    return out


def _ai(prompt: str, image_bytes: bytes | None = None, mime_type: str | None = None) -> dict[str, Any] | None:
    if not settings.gemini_api_key: return None
    try:
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=settings.gemini_api_key)
        contents: list[Any] = [prompt]
        if image_bytes and mime_type:
            contents.append(types.Part.from_bytes(data=image_bytes, mime_type=mime_type))
        response = client.models.generate_content(
            model=settings.gemini_model,
            contents=contents,
            config=types.GenerateContentConfig(
                temperature=0.35,
                max_output_tokens=1800,
                response_mime_type="application/json",
            ),
        )
        return _extract_json(response.text or "")
    except Exception:
        return None


def _normalize_ai(data: dict[str, Any] | None, budget: float, fallback: list[dict[str, Any]], planner: str):
    if not data: return fallback, False, "Gemini was not available; local demo recommendations were used."
    recs = []
    for item in data.get("recommendations", [])[:10]:
        try:
            price = float(item.get("price", 0))
            if price <= 0 or price > budget: continue
            platform = str(item.get("platform", "Search"))
            name = str(item.get("name", "Recommendation"))[:120]
            recs.append({"name": name, "category": str(item.get("category", planner)), "price": price, "platform": platform, "url": search_url(platform, name), "reason": str(item.get("reason", "AI-matched to your requirements."))[:300]})
        except (TypeError, ValueError): continue
    if not recs: return fallback, False, "Gemini returned no usable budget-safe items; local fallback was used."
    return recs, True, "Recommendations generated with Gemini; links open platform searches and should be checked for current price and availability."


def home(data):
    cats = {"furniture", "lighting", "decor"}
    fallback = _base_items("home", data.budget, cats)
    prompt = f'''You are PocketSmart AI's home budget planner. Budget: ₹{data.budget}. Rooms: {data.rooms}. Items: {[x.model_dump() for x in data.items]}. Style: {data.style}. City: {data.city}. Return JSON only with keys summary, allocation, recommendations. allocation must be an object of category to numeric rupees. recommendations must be an array of objects with name, category, price, platform, reason. Keep every price <= total budget and never claim live stock. Platforms may include Amazon, IKEA, Flipkart.''' 
    ai = _ai(prompt)
    recs, used, note = _normalize_ai(ai, data.budget, fallback, "home")
    allocation = ai.get("allocation", {}) if ai else {"furniture": round(data.budget*.45,2), "lighting": round(data.budget*.2,2), "decor": round(data.budget*.35,2)}
    return {"planner":"home","budget":data.budget,"allocation":allocation,"summary":(ai or {}).get("summary", "A balanced home setup using the requested rooms, style and budget."),"recommendations":recs,"ai_used":used,"note":note}


def party(data):
    fallback = _base_items("party", data.budget, {"catering", "decoration", "venue"})
    prompt = f'''You are PocketSmart AI's party budget planner. Budget ₹{data.budget}, guests {data.guests}, event {data.event_type}, venue {data.venue}, city {data.city}, preferences {data.preferences}. Return JSON only with summary, allocation, recommendations. Allocate across catering, venue, decoration and entertainment. Recommendations contain name, category, price, platform, reason. Total recommended spend must stay within budget. Do not claim live prices or availability.'''
    ai = _ai(prompt)
    recs, used, note = _normalize_ai(ai, data.budget, fallback, "party")
    allocation = ai.get("allocation", {}) if ai else {"catering": round(data.budget*.5,2), "venue": round(data.budget*.25,2), "decoration": round(data.budget*.15,2), "entertainment": round(data.budget*.1,2)}
    return {"planner":"party","budget":data.budget,"allocation":allocation,"summary":(ai or {}).get("summary", "A guest-aware party plan with room for catering, venue and decoration."),"recommendations":recs,"ai_used":used,"note":note}


def jewelry(data, image_bytes=None, mime_type=None):
    fallback = _base_items("jewelry", data.budget, {"earrings", "necklace"})
    prompt = f'''You are PocketSmart AI's jewelry stylist. Budget ₹{data.budget}, occasion {data.occasion}, preferred style {data.style}, outfit description {data.outfit_description}. If an outfit image is attached, use visible colors/patterns only to guide coordination. Return JSON only with summary, allocation, recommendations. Each recommendation has name, category, price, platform, reason. Keep every price <= budget and do not claim live availability.'''
    ai = _ai(prompt, image_bytes, mime_type)
    recs, used, note = _normalize_ai(ai, data.budget, fallback, "jewelry")
    allocation = ai.get("allocation", {}) if ai else {"jewelry": data.budget*.9, "buffer": data.budget*.1}
    return {"planner":"jewelry","budget":data.budget,"allocation":allocation,"summary":(ai or {}).get("summary", "Occasion-appropriate jewelry options matched to your style and budget."),"recommendations":recs,"ai_used":used,"note":note}
