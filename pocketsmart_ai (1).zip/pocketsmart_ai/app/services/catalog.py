"""Offline demo catalog. These are search links, not claims of live price/stock."""
from urllib.parse import quote_plus

HOME = [
    ("LED Ceiling Light", "lighting", 1299, "Amazon", "led ceiling light"),
    ("Pendant Light", "lighting", 2499, "IKEA", "pendant light"),
    ("Ceiling Fan", "appliance", 2899, "Amazon", "ceiling fan"),
    ("4-Seater Dining Table", "furniture", 8999, "IKEA", "4 seater dining table"),
    ("Accent Chair", "furniture", 6499, "Amazon", "accent chair"),
    ("Wall Art Set", "decor", 1799, "Amazon", "wall art set"),
    ("Storage Cabinet", "storage", 7499, "IKEA", "storage cabinet"),
    ("Area Rug", "decor", 3299, "IKEA", "area rug"),
    ("Bedside Table", "furniture", 2999, "IKEA", "bedside table"),
]
PARTY = [
    ("Veg Catering Package", "catering", 350, "Zomato", "veg catering"),
    ("Party Snacks Package", "catering", 180, "Swiggy", "party snacks"),
    ("Birthday Decoration Kit", "decoration", 1299, "Amazon", "birthday decoration kit"),
    ("LED String Lights", "decoration", 499, "Amazon", "LED string lights"),
    ("Banquet Room Search", "venue", 8000, "OYO", "banquet hall"),
]
JEWELRY = [
    ("Minimal Gold-Tone Earrings", "earrings", 799, "Amazon", "gold tone earrings"),
    ("Pearl Necklace Set", "necklace", 1499, "Flipkart", "pearl necklace set"),
    ("Kundan Earrings", "earrings", 1299, "Flipkart", "kundan earrings"),
    ("Oxidised Silver Jhumka", "earrings", 699, "Amazon", "oxidised silver jhumka"),
    ("Statement Necklace", "necklace", 2199, "Amazon", "statement necklace"),
]

def search_url(platform: str, query: str) -> str:
    domains = {"Amazon": "https://www.amazon.in/s?k=", "Flipkart": "https://www.flipkart.com/search?q=", "IKEA": "https://www.ikea.com/in/en/search/?q=", "Swiggy": "https://www.swiggy.com/search?query=", "Zomato": "https://www.zomato.com/search?q=", "OYO": "https://www.oyorooms.com/search?q="}
    return domains.get(platform, "https://www.google.com/search?q=") + quote_plus(query)

def catalog_for(planner: str):
    return {"home": HOME, "party": PARTY, "jewelry": JEWELRY}[planner]
