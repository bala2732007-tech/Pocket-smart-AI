from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from .config import get_settings
from .database import init_db
from .routers import auth, planners, session

BASE = Path(__file__).resolve().parent
settings = get_settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origin_list, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
templates = Jinja2Templates(directory=BASE / "templates")
app.include_router(auth.router)
app.include_router(planners.router)
app.include_router(session.router)

@app.get("/", response_class=HTMLResponse)
def index(request: Request): return templates.TemplateResponse(request=request, name="index.html")
@app.get("/health")
def health(): return {"status":"ok","service":settings.app_name}
@app.get("/startup")
def startup(): return {"status":"initialized"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
