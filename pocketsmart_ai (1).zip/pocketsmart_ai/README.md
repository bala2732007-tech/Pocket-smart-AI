# PocketSmart AI

A complete FastAPI + Jinja2 + SQLite + Gemini budget recommendation assistant based on the supplied project documentation.

## Features
- Home interior budget planner
- Party budget planner
- Jewelry planner with optional outfit image analysis
- Gemini AI integration with structured JSON output
- Local fallback catalog when Gemini is not configured or returns unusable data
- JWT authentication: register, login, logout
- Recommendation history and session endpoints
- Responsive browser UI
- API docs at `/docs`

## Important data behavior
The supplied specification mentions Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO. This implementation does not scrape or impersonate those sites. It creates search links and uses an offline demo catalog. Current price/stock is never claimed. Real commerce/vendor APIs can be added later behind `app/services/catalog.py`.

## Setup in VS Code
1. Install Python 3.11+.
2. Open this folder in VS Code.
3. Create a virtual environment:
   - Windows PowerShell: `py -m venv .venv` then `.venv\\Scripts\\Activate.ps1`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install: `pip install -r requirements.txt`
5. Copy `.env.example` to `.env`.
6. Put your Gemini API key in `GEMINI_API_KEY` for live AI. The app still runs without it using fallback recommendations.
7. Start: `uvicorn app.main:app --reload`
8. Open `http://127.0.0.1:8000`.

## Gemini
The project uses the current `google-genai` Python SDK. The model is configurable through `GEMINI_MODEL`. The supplied documentation names Gemini 1.5 Flash Pro, but model availability changes over time; keeping the model in `.env` avoids hard-coding an obsolete model.

## Test
`pytest -q`

## API routes
- POST `/register`
- POST `/login`
- POST `/logout`
- GET `/session-info`
- GET `/session-data`
- GET `/history`
- GET `/recommendations-details/{id}`
- POST `/generate-home`
- POST `/generate-party`
- POST `/generate-jewelry`
- GET `/health`
- GET `/startup`
